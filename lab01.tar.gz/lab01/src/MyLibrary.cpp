#include <iostream>
#include <string>

#include "../include/MyLibrary.h"

void PrintName(std::string text)
{
   std::cout << "[INFO]:: Name:"<< text << std::endl;
}


void PrintInfo(std::string text)
{
    std::cout << "[INFO]:: " << text << std::endl;
}