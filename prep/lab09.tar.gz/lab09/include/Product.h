#ifndef P
#define P

// #include <vector>
// #include "Warehouse.h"

// using namespace std;


// class Warehouse;

// class Product
// {
//     friend class Warehouse;

// public:
//     /** @brief Konstruktor domyslny
//     @return nic nie zwraca
//     */
//     Product();

//     /** @brief Konstruktor z parametrami
//     @param[in] t typ
//     @param[in] q ilosc
//     @return nic nie zwraca
//     */
//     Product(int t, int q);

//     /** @brief funkcja printujaca
//     funkcja wyswietla w terminalu wlasciwosci obiektu
//     @return nic nie zwraca
//     */
//     void Print();

//     /** @brief funkcja zmieniajaca pole obiektu
//     Funkcja zmienia ilosc obiektu
//     @param[in] q ilosc
//     @return  nic nie zwraca
//     */
//     void SetCard(int q);

// private:
//     int _type, _quan;

// };

#endif