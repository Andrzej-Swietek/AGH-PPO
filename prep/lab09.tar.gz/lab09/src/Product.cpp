// #include <iostream>
// #include "Product.h"
// #include <vector>

// using namespace std;

// Product::Product(): _type(0), _quan(0){};
// Product::Product(int t, int q): _type(t), _quan(q){};

// void Product::Print()
// {
//     cout << "typ: " << _type << ", ilosc sztuk: " << _quan << endl;
// }
// void Product::SetCard(int q)
// {
//     _quan = q;
// }